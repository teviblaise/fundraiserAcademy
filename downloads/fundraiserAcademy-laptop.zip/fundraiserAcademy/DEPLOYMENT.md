# Live server deployment

## Temporary Render preview

Connect GitHub to Render, choose **New → Blueprint**, select this repository,
and select the `preview/fundraiser-academy` branch. Render reads `render.yaml`
and creates a free Node.js web service. Alternatively, create a Web Service
from that branch with build command `npm ci --include=dev && npm run build`,
start command `npm run start:prod`, and environment variables `NODE_VERSION=24.19.0`
and `COOKIE_SECURE=true`.

After Render assigns the HTTPS URL, set `APP_ORIGIN` to that exact URL without
a trailing slash if using a custom domain. The server automatically uses
Render's `RENDER_EXTERNAL_URL` for its default public origin. Public pages and
pending client profiles can be viewed before email setup.
New users must confirm email before trading or assessment access. Verify a domain
in Resend, then add `RESEND_API_KEY` and `EMAIL_FROM` (a sender on that domain) in
Render Environment settings and redeploy. Render supplies the public HTTPS origin.
If sender setup is incomplete, registrations stay pending; they can resend
confirmation once delivery is configured. Existing accounts retain prior access.

Crypto reference execution and daily forex history need no API keys: allow outbound HTTPS to
`api.exchange.coinbase.com` and `api.frankfurter.dev`. Intraday forex execution
requires `TWELVE_DATA_API_KEY`, configured securely in Render's Environment settings,
and access to `api.twelvedata.com`. Daily ECB references cannot fill forex trades.
The Blueprint prompts for this secret during initial setup. A key saved in the
Codex cloud environment does not transfer to Render. For an existing service,
open its **Environment** settings, add `TWELVE_DATA_API_KEY` with your actual key
as the secret value, and choose **Save, rebuild, and deploy**. Confirm the service
uses `preview/fundraiser-academy` and deploys its latest commit. The running server
reads the key at startup, so a restart/redeploy is required after changing it.
Crypto live ticks additionally need outbound access to
`wss://ws-feed.exchange.coinbase.com`; REST quotes remain the fallback. Use
`CRYPTO_STREAMING_ENABLED=false` to disable that connection explicitly. The
dashboard's same-origin `/api/account-stream` uses authenticated Server-Sent
Events; reverse proxies should keep the connection open and avoid buffering it.
Twelve Data Basic forex uses the existing periodic REST quotes, rather than
WebSocket ticks. A browser receiving live account events does not change the
underlying forex provider's update frequency or credit limits.
All ten forex pairs need provider-plan coverage. Yen crosses additionally fetch
USD/JPY and EUR/GBP fetches GBP/USD to convert account values into USD; include
that traffic when choosing a quote allowance. Conversion outages pause fills.
TradingView charts load in
the visitor's browser and require its script/iframe domains to be accessible.
After deployment, check a crypto reference quote/candles and a forex daily quote
and chart; confirm source times and that source failures are visibly marked.
Challenge fills, stops, limits, P&L, and price alerts use fresh server-verified
reference prices. No generated feed or added spread is used. Missing, stale, or
closed-market quotes pause execution; never enable a fallback for challenge fills.

If forex is paused, read the message below the order ticket. A missing-key message
means the running Render service has not received its key; a quota/access message
means the provider is refusing the request. Stale quotes and closed markets wait
for fresh prices. If the ticket is active but candles are blank, try **Daily
closes** to distinguish the external TradingView chart from execution quotes.

The Blueprint explicitly deploys `preview/fundraiser-academy` and checks
`/healthz` before routing requests to the service. Render supplies the `PORT`;
the server listens on that port on all interfaces. The build installs the locked
dependencies and compiles Tailwind, and the runtime starts the Node.js backend.

This free preview uses temporary storage: accounts, certificates, and push keys
can disappear on restarts or redeploys. Free services may sleep when idle. Use
disposable test accounts. For lasting records, use a paid service with a persistent
disk and set `DATABASE_PATH` to a file on that disk. Delete the service in Render
when the preview is no longer needed.

The laptop ZIP is in `downloads/fundraiserAcademy-laptop.zip`; it includes the
website and backend but excludes user databases and credentials.

The company-provided revised section is bundled privately at
`agreements/progressive-profit-sharing-v1.txt` and published idempotently on startup.
It supplies the exact progressive-sharing and tier-retention clauses, without
inventing other legal provisions. A new revision requires a trader's explicit
signature after qualification. Existing documents and signatures stay immutable;
startup must not reactivate this revision over a later company publication.

For later company-approved revisions, publish the PDF or UTF-8 text from the admin
console or `contract:publish`. For services without a shell, set `CONTRACT_FILE`,
`CONTRACT_VERSION`, and optional `CONTRACT_TITLE` to the actual private document.
Keep personal completed contracts out of Git and `public/`. Free preview storage
cannot preserve signatures reliably; use a persistent disk for real signing.

This app needs a Node.js backend. Static hosting and the VS Code Live Server
extension cannot run registration, saved trading records, certificates, or delivery.
Use Node.js 24+ on a persistent server or a Docker-capable hosting service.

## Deploy with Node.js

Extract the release package into a private application directory, then run:

```sh
npm ci --include=dev
npm run build
npm prune --omit=dev
npm run start:prod
```

Use a process manager to restart the app after server reboots. Expose it through
an HTTPS reverse proxy; the Node server defaults to port 3000. Do not expose the
data directory as web content. Supply secrets using the host's environment settings.

### Reverse proxy client addresses

`TRUST_PROXY_HOPS` defaults to `0`, which rate-limits using the actual socket
peer and ignores client-supplied forwarded headers. Behind a reverse proxy this
can group visitors under the proxy's address. Set a positive value only after
verifying the number of trusted forwarding hops on every route to this server.
For example, a single controlled proxy that appends the connecting client's IP
to `X-Forwarded-For` uses `TRUST_PROXY_HOPS=1`. The application selects from the
right-hand end of the validated address chain, rather than accepting an
attacker-supplied leftmost address. Malformed or insufficient chains fall back to
the socket peer.

The proxy must append or overwrite `X-Forwarded-For`, and clients must not be able
to bypass it and connect to the Node port directly. Restrict that port to the
proxy, as in the Docker example below. Never guess a hop count from an arbitrary
request header or enable trust for a directly exposed Node server. For an existing
Render service, confirm its ingress behavior with Render before setting this
variable in **Environment** and redeploying. Editing the Blueprint does not update
an existing service's environment. Rate-limit isolation remains unverified there
until the actual proxy topology and runtime setting have been checked.

HTTPS deployments send `Strict-Transport-Security: max-age=31536000` when
`APP_ORIGIN` uses HTTPS, including the automatic Render origin. It deliberately
does not include subdomains or request HSTS preload registration. All HTTP
responses carry browser framing and referrer protections; the private agreement
viewer retains its same-origin document iframe.

## Deploy with Docker

```sh
docker build -t fundraiser-academy .
docker volume create fundraiser-academy-data
docker run -d --name fundraiser-academy --restart unless-stopped \
  -p 127.0.0.1:3000:3000 \
  --env-file /secure/path/fundraiser-academy.env \
  --mount source=fundraiser-academy-data,target=/app/data \
  fundraiser-academy
```

Create that environment file privately, with permissions restricted to the operator.
Use the fields in `.env.example` as a reference. Never commit real credentials.
Place an HTTPS reverse proxy in front of port 3000 and configure your actual domain.
The image runs as an unprivileged user. For a host bind mount instead of a named
volume, ensure the data directory is writable by container UID 1000.

## Required production settings

- `APP_ORIGIN`: the exact public HTTPS origin, with no trailing slash/path.
- `COOKIE_SECURE=true`: session cookies must use HTTPS.
- `DATABASE_PATH`: a file on persistent storage, not a temporary build directory.
- `RESEND_API_KEY` and `EMAIL_FROM`: required for signup confirmation, password recovery/security notices, and opted-in alert emails.
- `ADMIN_OWNER_EMAILS`: exact registered email address(es) for initial owner access; every owner must also confirm email and enable authenticator 2FA.
- `BACKUP_DIRECTORY`: optional private persistent backup directory; defaults to `backups/` beside the database.
- `BACKUP_INTERVAL_HOURS` and `BACKUP_RETENTION_COUNT`: default to 24 hours and seven retained encrypted artifacts.
- `BACKUP_ENCRYPTION_KEY`: optional stable, directly injected 32-byte base64 encryption key; otherwise preserve the generated private `backup-key.json` separately.

Preserve the SQLite database, `two-factor-key.json`, and `vapid.json` in its private
directory, or retain the original directly injected authenticator encryption key.
Replacing the
VAPID key pair invalidates existing browser push subscriptions. Back up SQLite
using the included SQLite-aware operations service and restrict access to database
and backup files. Keep a separate secure copy of the backup encryption key: it is
not included inside the encrypted artifacts. A backup and its only decryption key
on the same temporary instance do not provide disaster recovery.

## Activate the admin dashboard

The console is served at `/admin.html`. A deployment does not create or verify an
owner account. To activate it:

1. In the running Render service's **Environment** settings, set
   `ADMIN_OWNER_EMAILS` to the exact email the owner will register and deploy the
   updated configuration. For a new Blueprint, enter it when prompted. Existing
   services must add it separately; a value saved in Codex cloud settings or a
   Git change to `render.yaml` does not establish that the running service has it.
2. Configure `RESEND_API_KEY` and a sender on a domain verified in Resend as
   `EMAIL_FROM`. Register the owner normally and confirm the email link. Older
   accounts also need actual email verification for admin access.
3. Sign in, open Security, enable the authenticator, and save recovery codes
   privately. Then open `/admin.html`. An active account, confirmed email, and
   enrolled 2FA are all required, even for an environment-managed owner.
4. Before editing records or exporting a report, confirm the password and a fresh
   second-factor code in the console. This grants five minutes of privileged
   access to that session; sign-out, security changes, or role changes invalidate
   the proof. An already used authenticator code cannot be reused.

Owners can assign `owner`, `admin`, `reviewer`, or `support` roles to other
registered, verified, 2FA-enabled staff. A trusted server shell can also run
`npm run admin:staff -- list`, or
`npm run admin:staff -- grant --email registered-staff@your-domain.example --role reviewer --reason "Assign assessment reviews."`.
Use `revoke --email ... --reason "..."` to remove a database-managed role. All CLI
changes use the existing `DATABASE_PATH`, record an audit entry, and revoke that
account's sessions. They do not verify email or disable 2FA. Environment-managed
owners must be changed in `ADMIN_OWNER_EMAILS` and the server restarted.

Admin-console support access requires the same verified-email and 2FA gates.
`SUPPORT_STAFF_EMAILS` and `support:staff` remain independent legacy inbox grants;
review both if removing all support access for a staff member. A free Render
service may not provide shell access, so the owner environment setting is the
hosted bootstrap path.

Publish only the company-provided PDF or UTF-8 text agreement from the console or
the existing `contract:publish` command. A new active version requires a new
trader signature and a current review. Do not publish test terms on the real site.
Record external sponsored accounts only after review approval and verification
of the actual account evidence. New accounts under the supplied progressive
section use the company's 50%/60%/70% structure; staff cannot choose an arbitrary
standard split. Record only eligible prop payouts actually received and cleared by
the company, after firm deductions and agreed transaction charges. Equity feeds
and unsettled statements never establish qualifying receipts. Use USD cents and
real evidence; review duplicates before submitting immutable entries.

The threshold-crossing receipt uses the pre-receipt tier. The next eligible
receipt gets the upgrade. Aggregate receipts across eligible accounts in the
continuous relationship; closing or replacing an account does not reset it.
Ordinary losses and failures do not create a debt owed by the trader.

Existing fixed-share account terms and legacy statements remain intact. They
cannot be retroactively converted or silently reduced. Staff must document any
required contractual adoption or reinstatement terms before new sponsorship,
including treatment of the previously earned tier. Termination leaves accrued
unpaid shares payable under the agreement.

For reinstatement, use the Fundraiser's admin profile to prepare the private
reinstatement agreement with an explicit starting tier and written reference.
Publish the prepared, unchanged document to **that Fundraiser's client ID only**,
then have the Fundraiser read and personally sign it and obtain a new sponsorship
review. Only afterward record reinstatement with the same reference and tier.
The backend verifies the exact signed document, recipient, and termination basis;
an administrative consent checkbox is insufficient. Publishing a personal
agreement does not replace the standard agreement or invalidate other members'
reviews. The trusted CLI supports `--recipient-user-id CLIENT_ID` for personal
publication; generic publication remains for actual company-wide terms.

The standard automated schedule implements 50%/60%/70%. Existing nonstandard
fixed shares are preserved; a custom written exception needs a separately
reviewed financial model before automatic adoption. Do not enter a false cleared
funds date to import cash received before the recorded relationship began.

For every cleared receipt, review the payout statement and three-business-day
payment-initiation deadline. Operational counting uses Monday–Friday in
Africa/Lagos. Record real initiation evidence separately from final external
payment. Monitor outstanding entitlements even if the client has not requested a
withdrawal. Operations flags overdue receipt entitlements and the original
initiation deadline survives partial reservations, rejection, and re-request. Payout actions reserve or record ledger amounts; they do not contact a
bank, issue a prop account, or prove that a payment took place.

Keep the private database and keys on persistent storage before collecting lasting
admin decisions, signatures, or financial records. The free preview remains
ephemeral. Audit records, posted statements, and financial terms are append-only
or immutable in the application. The included scheduled local backup service does
not supply persistent disks, offsite storage, or a company retention policy;
operators still need those and periodic staff-access reviews.

## Account controls and performance validation

Clients access `/account-tools.html` from the client dashboard or Security.
Export, deletion, and payout requests each use a separate five-minute confirmation
bound to the signed-in session, password, and a fresh second factor when enabled.
Use disposable test users to verify full paginated JSON export, a retry after an
exported record changes, idempotent payout retries, and payment-status history.
The browser declines a partial or changed export instead of calling it complete.

Test both account-closure outcomes. Open sponsored allocations, unresolved payouts,
unsettled earnings, or staff/support roles keep the request pending and preserve
login so obligations can be resolved; the owner can cancel it. Once eligible, the
literal confirmation closes the usable profile, signs out devices, and removes
mutable operational data. Keep the returned receipt: immutable agreements,
financial records, review/audit records, and earlier backups may remain as
explicitly disclosed. Finalize the company retention/deletion policy before
collecting lasting customer records. Do not test deletion on a real client or
the only owner account to prove the feature works.

`/performance.html` and the admin Performance analysis section use recorded data.
Verify monthly UTC results, fees, deposit/withdrawal classification, and native
currency against known records. Historical closed assessment fills may produce a
labeled realized balance curve; marked equity starts only when observations are
captured. No unrecorded equity is reconstructed. Check coverage/staleness notices,
closing-fill versus round-trip-position counts, and cash-flow-adjusted drawdown
before using statistics for company decisions. Consistency statistics do not add
new assessment rules.

## Operational health and diagnostics

Sign in to `/admin.html` and open **Operations & recovery**. The health report
combines local database/storage checks, backup freshness and failures, notification
queue totals, email/forex configuration, and open
server incidents. Metrics and the downloadable JSON report contain aggregate
values, not recipient addresses, provider account IDs, filesystem paths, or keys.
Use Refresh for a current observation. Keep detailed checks behind staff access;
public `/healthz` remains a minimal availability endpoint.

**Run diagnostics** requires fresh staff authentication and an audit reason. It
performs bounded, read-only SQLite `quick_check` and foreign-key checks in a separate
subprocess, plus a private-storage temporary write probe that is cleaned up afterward.
Recent results are recorded. It does not repair records, send test messages,
contact market providers, or replace the database.

Treat each reported action as an operator task:

- For failed/overdue notifications, check the application's Resend sender/origin
  settings and provider delivery logs. Confirm delivery using an inbox you control;
  configuration alone is not delivery evidence. Review failed messages before
  deciding whether to request new confirmations or password-reset links.
- For low or unavailable storage, inspect the hosting volume and permissions.
  Expand durable storage or follow retention policy; do not remove live SQLite,
  WAL, authentication keys, or the only usable backup to silence a warning.
- For failed or overdue backups, inspect the latest safe job code, available
  storage, and original encryption key. Create a new backup and run its isolated
  recovery check after resolving the cause.
- For a failed database diagnostic, preserve the current installation and involve
  its operator. Check a verified backup in isolation before planning recovery;
  this report provides no automatic live repair.

Missing offsite protection and unverified persistence remain visible operator
requirements. Available capacity cannot establish that Render storage survives
restarts or that a separate offsite copy exists. Diagnostic results also cannot
prove provider availability, external delivery, or a complete disaster-recovery
procedure. Never put secrets or private customer records in reasons, chat, or logs.

Trusted operators can also run `npm run operations -- health` and
`npm run operations -- diagnose`. Health exits 0 for `healthy`, 2 for `attention`
or `critical`; diagnostics exits 0 for `ok`, 2 for `warning` or `critical`. Both
exit 1 for command/usage failures. The CLI reports its own runtime and does not
start background schedulers; use the running admin view to inspect application
workers.

## Scheduled backups and recovery checks

The running application schedules an initial backup after about 30 seconds and
then defaults to a 24-hour interval, retaining seven artifacts by count. Use
`BACKUP_INTERVAL_HOURS` and `BACKUP_RETENTION_COUNT` for supported alternatives.
Each SQLite-consistent encrypted backup includes required authenticator and VAPID
keys and is checked in an isolated temporary directory. SHA-256 manifest checks,
authenticated decryption, database integrity/foreign keys, authentication-key
checks, and replay of the current deletion ledger must succeed. The live database
is not replaced by a check. The admin **Operations & recovery** section exposes
sanitized error counts, backup runs, and verification results, with fresh staff
authentication required to start a backup or check.

Keep the database directory and `BACKUP_DIRECTORY` private and persistent. The
default is local storage, with **no offsite backup destination configured**.
Render free-preview storage can lose the database, local artifacts, and generated
keys together. Copy verified artifacts and the latest protected deletion ledger
through an operator-managed offsite process and preserve the encryption key
separately; this release does not automate that external process. The backup
key is the stable directly supplied `BACKUP_ENCRYPTION_KEY`, or a generated
`backup-key.json` beside the database. Do not rotate or discard it while its
artifacts remain needed. Encryption keys and live backups are excluded from Git,
container build context, and the downloadable source ZIP.

Run these commands on the trusted installation using its existing `DATABASE_PATH`:

```sh
npm run operations -- status
npm run operations -- health
npm run operations -- diagnose
npm run operations -- backup
npm run operations -- verify
npm run operations -- verify --backup BACKUP_UUID
npm run operations -- restore --backup BACKUP_UUID --target /secure/new-academy-recovery --confirmation "RESTORE TO NEW DIRECTORY"
```

The CLI requires the healthy current academy database, backup registry, current
deletion ledger, relevant artifact, and correct encryption key. A restore writes
only to a new private target and refuses an existing directory; it never replaces
the running database. This is fresh-copy recovery and verification, **not a
standalone disaster-recovery tool for a lost database or host**. Plan and validate
that separate procedure before relying on these records operationally.

The recovered copy reapplies completed account deletions and reserves deleted
user IDs so they cannot be resurrected by an older backup. It also revokes old
sessions, recovery-code hashes, pending login/reset/confirmation tokens, push
subscriptions, and queued notification jobs. Non-deleted accounts must complete a
new password reset before sign-in. Enabled authenticators stay enabled, using the
restored original encryption key. Confirm working recovery email delivery and
retain access to the original authenticator before operator-controlled activation;
there is no automatic 2FA bypass. Regenerate recovery codes after access is restored.

Monitor failed jobs and open error fingerprints in Operations. Monitoring stores
bounded generic categories, codes, sanitized routes, and occurrence counts, not
raw request bodies, exception text, or credentials. External alerting, offsite
delivery, and operational staffing remain the operator's responsibility.

## Verify after deployment

Visit registration, use an email address you control, and confirm the client
dashboard opens in a pending state. Confirm the one-time inbox link, then test
assessment access, login/logout, a simulated trade, price alert, and popup. Confirm records
persist across a server restart. My certificates should be accessible only after
login. Use the automated tests to verify certificate rules without forging a live
candidate result. Test a real email confirmation and an opted-in push notification
with the browser page closed on a supported device.

Email and push delivery require network access to `api.resend.com`,
`fcm.googleapis.com`, `*.push.services.mozilla.com`, and `web.push.apple.com`.
Browsers may block notifications or restrict background delivery. Check the dashboard
queue status and provider logs without exposing API keys or subscription URLs.

## Release contents and limitations

The release archive includes source, compiled CSS, lockfile, tests, brand assets,
and deployment instructions. It excludes live databases, VAPID private keys,
credentials, Git metadata, and installed dependencies. Deploying this archive
starts with no users; migrating existing records requires a separate protected
database/key backup and restore.

Required signup confirmation, password recovery, optional alert verification,
the admin console, account controls, payout requests, advanced reports, and encrypted
local backup/recovery checks are implemented.
Complete privacy/retention policies, persistent/offsite storage, working provider
credentials, and payment execution are separate operator requirements. Manual
payment confirmations do not transfer funds; review README.md and
ACADEMY_PLAYBOOK.md before public enrollment.


## Customer support

The Academy guide and persistent handoff queue work without an AI credential.
For generative replies, add `SUPPORT_AI_API_KEY` securely to Render Environment
settings and redeploy; optional `SUPPORT_AI_MODEL` defaults to `gpt-4.1-mini`.
The server requires outbound HTTPS to `api.openai.com`. A key in cloud environment
settings is separate from Render. Never put the key into browser code or Git.

Set `SUPPORT_STAFF_EMAILS` to your registered, email-verified agent addresses and
redeploy. Agents sign in normally and open `/support-agent.html`; clients cannot
access their inbox. The human queue retains the transcript and stops AI replies
when a handoff is requested. Until you configure staff, requests remain queued.
The alternative local `npm run support:staff -- grant --email ...` command operates
on `DATABASE_PATH`; free Render plans may not offer shell access, so the environment
allowlist is the simpler hosted setup. Staff verification still needs your Resend
sender configuration. Confirm a real agent can claim and reply to a test request
before advertising staffed support hours.


## Contract trader leaderboard

The public `/leaderboard.html` page and `/api/leaderboard` need no additional
provider keys. They read qualified certificates, current contract signatures, and
opt-in aliases from the private application database. Participants manage their
visibility on that page after signing in. No legal names, emails, account IDs,
signatures, or certificate documents are exposed by the public ranking.

A company-supplied active agreement is required before any trader is eligible.
Do not publish test terms or manufacture entries to populate the live page. The
metric is the signed qualifying assessment's realized return, not post-contract
sponsored-account profit. Keep the same persistent SQLite database so signatures
and public participation preferences survive deployments.

## Password recovery

The Forgot password link on the login page uses the same Resend configuration as
signup confirmation. Set `RESEND_API_KEY`, a sender verified with Resend in
`EMAIL_FROM`, and the public HTTPS origin (automatic on Render unless overridden).
Use an inbox you control to verify request, receipt, single-use reset, old-password
rejection, and sign-in with the new password. Reset links expire in 20 minutes.
The request page always gives a generic response, so an accepted request alone
is not proof of delivery. Security emails are transactional and do not need trade
alert opt-in. No new secret or paid recovery service is required.

## Authenticator security and persistent sessions

Authenticator codes need no SMS or external 2FA provider. Account email ownership
must be confirmed through the existing Resend flow before first enrollment,
including older accounts. The Security page
creates its QR code locally and supports authenticator apps plus recovery codes.
Use HTTPS and secure cookies. Confirm setup, save codes privately, verify a fresh
login requires the second factor, then test device sign-out using browsers you
control. No passwords, setup seeds, QR images, or recovery codes belong in logs.

The encryption key defaults to `two-factor-key.json` in the private database
directory. Persist and back up the database and this key together. A Render disk
mounted at the database directory preserves both; ephemeral free-preview storage
is unsuitable for lasting real account records. An optional stable
`TWO_FACTOR_ENCRYPTION_KEY` is a directly injected 32-byte base64 server secret.
Do not create a proxy-only API-key binding for local encryption, do not generate
a new value at every deploy, and do not change the key after factors are enrolled.
Restore the original key with existing encrypted records. Recovery codes remain
usable if a key is lost, while authenticator verification fails closed. The laptop
ZIP creates its own independent key and never includes cloud accounts or keys.

Session metadata migrates additively. Current valid sessions retain access unless
a factor change, password reset, or owner revocation removes them. Sessions have a
seven-day absolute lifetime and a 24-hour idle deadline. Revocation also invalidates
pending sign-in challenges and in-flight login proofs; signing out devices does
not delete trading history or disable background protective account checks.
