import { DatabaseSync, backup as sqliteBackup } from 'node:sqlite';
import { createCipheriv, createDecipheriv, createECDH, createHash, randomBytes, randomUUID } from 'node:crypto';
import { appendFileSync, chmodSync, closeSync, constants, createReadStream, createWriteStream, existsSync, fsyncSync, linkSync, lstatSync, mkdirSync, mkdtempSync, openSync, readFileSync, realpathSync, readdirSync, renameSync, rmSync, statSync, unlinkSync, writeFileSync } from 'node:fs';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { createGzip, createGunzip } from 'node:zlib';
import { isMainThread, parentPort, Worker, workerData } from 'node:worker_threads';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const magic=Buffer.from('FADBKP01');
const aad=Buffer.from('FundraiserAcademy:EncryptedBackup:v1');
const uuid=/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i;
const publicRoot=path.resolve(fileURLToPath(new URL('./public/',import.meta.url)));
const fileNames=new Set(['academy.sqlite','two-factor-key.json','vapid.json']);
const routeWords=new Set(('api admin account status authorize export delete cancel payouts request performance sponsored-accounts connections link unlink sync operations backup check privacy complete healthz security 2fa setup confirm disable recovery-codes sessions revoke revoke-all revoke-others me profile login logout register registration-status email resend-confirmation request-verification preferences push subscribe unsubscribe market account-stream account quotes trades close limits stops alerts reset certificates contracts document leaderboard support messages conversations claim reply resolve staff reviews traders assessments accounts statements reports audit system verify-password forgot-password reset-password process uncaught internal background reference-market feed').split(' '));
const digest=value=>createHash('sha256').update(value).digest('hex');
const failure=(status,code,message)=>Object.assign(new Error(message),{status,code});
const has=(db,table)=>Boolean(db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?").get(table));
const rowCount=(db,table)=>has(db,table)?db.prepare(`SELECT count(*) n FROM ${table}`).get().n:0;
const processAlive=pid=>{if(!Number.isSafeInteger(pid)||pid<1)return false;try{process.kill(pid,0);return true;}catch(error){return error.code==='EPERM';}};
const failSafe=()=>failure(503,'OPERATIONS_FAILED','The operational check could not complete. Review the recorded status and private storage configuration.');
function integer(value,fallback,min,max,label){if(value===undefined||value===null||value==='')return fallback;if(typeof value!=='number'&&(typeof value!=='string'||!/^\d+$/.test(value)))throw failure(400,'OPERATIONS_INVALID_INPUT',`Provide a valid ${label}.`);const n=Number(value);if(!Number.isSafeInteger(n)||n<min||n>max)throw failure(400,'OPERATIONS_INVALID_INPUT',`Provide a valid ${label}.`);return n;}
function parseKey(value,label){if(typeof value!=='string'||!/^[A-Za-z0-9+/]{43}=$/.test(value))throw failure(503,'BACKUP_KEY_INVALID',`${label} must be a stable base64-encoded 32-byte key.`);const key=Buffer.from(value,'base64');if(key.length!==32||key.toString('base64')!==value)throw failure(503,'BACKUP_KEY_INVALID',`${label} must be a stable base64-encoded 32-byte key.`);return key;}
function notPublic(value){const full=path.resolve(value);if(full===publicRoot||full.startsWith(publicRoot+path.sep))throw failure(400,'BACKUP_PATH_UNSAFE','Backups and recovery targets must stay outside public/.');return full;}
function noSymlink(value){const absolute=path.resolve(value);let current=path.parse(absolute).root;for(const piece of absolute.slice(current.length).split(path.sep).filter(Boolean)){current=path.join(current,piece);try{if(lstatSync(current).isSymbolicLink())throw failure(400,'BACKUP_PATH_UNSAFE','Backup and recovery paths must not contain symbolic links.');}catch(error){if(error.code!=='ENOENT')throw error;}}return notPublic(absolute);}
function privateDirectory(value){const full=noSymlink(value);mkdirSync(full,{recursive:true,mode:0o700});if(!lstatSync(full).isDirectory())throw failure(400,'BACKUP_PATH_UNSAFE','Use a private directory for backups.');notPublic(realpathSync(full));if(process.platform!=='win32')chmodSync(full,0o700);return full;}
function privateRead(filename,{required=true}={}){if(!existsSync(filename)){if(required)throw failure(503,'BACKUP_KEY_MISSING','A required private authentication key is unavailable.');return null;}const meta=lstatSync(filename);if(!meta.isFile()||meta.isSymbolicLink()||(process.platform!=='win32'&&(meta.mode&0o077)))throw failure(503,'BACKUP_KEY_PERMISSIONS','Authentication keys must be private regular files.');if(meta.size>16384)throw failure(503,'BACKUP_KEY_INVALID','A private authentication key has an invalid size.');return readFileSync(filename);}
function loadBackupKey(filename,provided,backupDirectory){if(provided!==undefined&&provided!=='')return{key:parseKey(provided,'BACKUP_ENCRYPTION_KEY'),source:'environment'};if(!existsSync(filename)){if(readdirSync(backupDirectory).some(name=>name.endsWith('.fabackup')))throw failure(503,'BACKUP_KEY_MISSING','Existing encrypted backups require their original backup key.');const temporary=`${filename}.${randomBytes(10).toString('hex')}.tmp`;try{const fd=openSync(temporary,constants.O_CREAT|constants.O_EXCL|constants.O_WRONLY,0o600);try{writeFileSync(fd,JSON.stringify({version:1,key:randomBytes(32).toString('base64')})+'\n');fsyncSync(fd);}finally{closeSync(fd);}try{linkSync(temporary,filename);}catch(error){if(error.code!=='EEXIST')throw error;}}finally{if(existsSync(temporary))unlinkSync(temporary);}}let parsed;try{parsed=JSON.parse(privateRead(filename).toString('utf8'));}catch{throw failure(503,'BACKUP_KEY_INVALID','The private backup key could not be loaded.');}if(parsed.version!==1)throw failure(503,'BACKUP_KEY_INVALID','The private backup key version is unsupported.');return{key:parseKey(parsed.key,'The backup key'),source:'private_file'};}
function claimBackupDirectory(directory,source){
 const marker=path.join(directory,'.academy-owner.json'),expected=digest(source);
 try{writeFileSync(marker,JSON.stringify({version:1,source:expected})+'\n',{mode:0o600,flag:'wx'});}catch(error){if(error.code!=='EEXIST')throw error;}
 let stored;try{stored=JSON.parse(privateRead(marker).toString('utf8'));}catch{throw failure(503,'BACKUP_DIRECTORY_IN_USE','The backup directory ownership marker is unavailable or invalid.');}
 if(stored.version!==1||stored.source!==expected)throw failure(409,'BACKUP_DIRECTORY_IN_USE','Use a separate backup directory for each academy database.');
}
function schemaHash(db){return digest(JSON.stringify(db.prepare("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name").all()));}
function deletionLedger(db,now){const installation=has(db,'account_control_metadata')?db.prepare('SELECT installation_id id FROM account_control_metadata WHERE singleton=1').get()?.id:null;const entries=has(db,'account_deletions')?db.prepare("SELECT user_id userId,request_id requestId,requested_at requestedAt,completed_at completedAt,status FROM account_deletions WHERE status='deleted' ORDER BY user_id").all():[];return{version:1,installationId:installation,generatedAt:now,entries};}
function ledgerFingerprint(ledger){return digest(JSON.stringify({version:ledger?.version,installationId:ledger?.installationId,entries:ledger?.entries}));}
function mergeLedgers(archived,current){
 if(!current)return archived;
 if(!archived)return current;
 if(archived.installationId!==current.installationId)throw failure(503,'RECOVERY_LEDGER_REQUIRED','The backup and current deletion ledger must belong to the same installation.');
 if(!Array.isArray(archived.entries)||!Array.isArray(current.entries))throw failure(503,'RECOVERY_LEDGER_REQUIRED','A valid current deletion ledger is required for recovery.');
 const entries=new Map();
 for(const item of [...archived.entries,...current.entries]){
  const previous=entries.get(item.userId);
  if(previous&&previous.requestId!==item.requestId)throw failure(503,'RECOVERY_LEDGER_REQUIRED','Conflicting account-deletion records prevent recovery.');
  entries.set(item.userId,item);
 }
 return{...current,entries:[...entries.values()].sort((a,b)=>a.userId-b.userId)};
}
function clearRestoredAuthentication(db){const columns=db.prepare('PRAGMA table_info(users)').all();if(!columns.some(x=>x.name==='recovery_required'))db.exec('ALTER TABLE users ADD COLUMN recovery_required INTEGER NOT NULL DEFAULT 0');db.prepare('UPDATE users SET recovery_required=1').run();if(columns.some(x=>x.name==='session_version'))db.prepare('UPDATE users SET session_version=session_version+1 WHERE session_version<?').run(Number.MAX_SAFE_INTEGER);for(const table of ['sessions','admin_step_up','account_tool_privileges','two_factor_challenges','two_factor_recovery_codes','password_resets','email_verifications','push_subscriptions'])if(has(db,table))db.prepare(`DELETE FROM ${table}`).run();if(has(db,'two_factor'))db.prepare('UPDATE two_factor SET pending_secret=NULL,pending_expires=NULL,version=version+1').run();if(has(db,'notification_outbox'))db.prepare("UPDATE notification_outbox SET status='cancelled',payload='{}' WHERE status IN ('pending','sending')").run();if(has(db,'operations_job_lease'))db.prepare('DELETE FROM operations_job_lease').run();if(has(db,'operations_temporary_paths'))db.prepare('DELETE FROM operations_temporary_paths').run();if(has(db,'operations_runs'))db.prepare("UPDATE operations_runs SET status='failed',failure_code='RECOVERY_RESTORED' WHERE status='running'").run();return rowCount(db,'users');}
function checkAuthenticationKeys(db,directory){let factorCount=0;const keyFile=path.join(directory,'two-factor-key.json');const factors=has(db,'two_factor')?db.prepare('SELECT user_id,secret FROM two_factor WHERE secret IS NOT NULL').all():[];if(factors.length){let key;try{const stored=JSON.parse(privateRead(keyFile).toString('utf8'));if(stored.version!==1)throw new Error();key=parseKey(stored.key,'The authentication key');for(const row of factors){const[v,iv,tag,ciphertext,extra]=String(row.secret).split(':');if(v!=='v1'||extra!==undefined)throw new Error();const decipher=createDecipheriv('aes-256-gcm',key,Buffer.from(iv,'base64'));decipher.setAAD(Buffer.from(`FundraiserAcademy:TOTP:${row.user_id}:v1`));decipher.setAuthTag(Buffer.from(tag,'base64'));const secret=Buffer.concat([decipher.update(Buffer.from(ciphertext,'base64')),decipher.final()]).toString('utf8');if(!/^[A-Z2-7]{32,}$/.test(secret))throw new Error();factorCount++;}}catch{throw failure(503,'RECOVERY_AUTH_KEY_FAILED','The backup authentication key does not match the encrypted authenticator records.');}}const vapidFile=path.join(directory,'vapid.json');let pushKeyChecked=false;if(existsSync(vapidFile)){try{const keys=JSON.parse(privateRead(vapidFile).toString('utf8'));const curve=createECDH('prime256v1');curve.setPrivateKey(Buffer.from(keys.privateKey,'base64url'));if(curve.getPublicKey().toString('base64url')!==keys.publicKey)throw new Error();pushKeyChecked=true;}catch{throw failure(503,'RECOVERY_PUSH_KEY_FAILED','The backup notification key pair is invalid.');}}else if(rowCount(db,'push_subscriptions')>0)throw failure(503,'RECOVERY_PUSH_KEY_FAILED','The backup is missing its notification key pair.');return{authenticatorRecordsChecked:factorCount,pushKeyChecked};}
async function fileHash(filename){const hash=createHash('sha256');for await(const chunk of createReadStream(filename))hash.update(chunk);return hash.digest('hex');}

async function packBackup({directory,destination,key,createdAt,ledger,maxBytes}){
 const snapshot=new DatabaseSync(path.join(directory,'academy.sqlite'));let hash;
 try{snapshot.exec('PRAGMA secure_delete=ON; VACUUM;');hash=schemaHash(snapshot);}finally{snapshot.close();}
 const files=[];let total=0;
 for(const name of fileNames){const filename=path.join(directory,name);if(!existsSync(filename))continue;const info=lstatSync(filename);if(!info.isFile()||info.isSymbolicLink())throw failSafe();total+=info.size;if(total>maxBytes)throw failure(503,'BACKUP_TOO_LARGE','The local backup exceeds its configured size limit.');files.push({name,size:info.size,sha256:await fileHash(filename)});}
 const manifest={version:1,createdAt,schemaHash:hash,installationId:ledger.installationId,files,deletionLedger:ledger};const metadata=Buffer.from(JSON.stringify(manifest));if(metadata.length>16*1024*1024)throw failure(503,'BACKUP_TOO_LARGE','The deletion ledger exceeds the local backup metadata limit.');const length=Buffer.alloc(4);length.writeUInt32BE(metadata.length);
 const iv=randomBytes(12);writeFileSync(destination,Buffer.concat([magic,iv]),{mode:0o600,flag:'wx'});const cipher=createCipheriv('aes-256-gcm',Buffer.from(key),iv);cipher.setAAD(aad);
 async function* contents(){yield length;yield metadata;for(const file of files)for await(const chunk of createReadStream(path.join(directory,file.name)))yield chunk;}
 await pipeline(Readable.from(contents()),createGzip(),cipher,createWriteStream(destination,{flags:'a',mode:0o600}));appendFileSync(destination,cipher.getAuthTag());const fd=openSync(destination,'r');try{fsyncSync(fd);}finally{closeSync(fd);}return{bytes:statSync(destination).size,schemaHash:hash,files:files.map(x=>({name:x.name,size:x.size})),createdAt};
}
async function unpackBackup({filename,directory,key,maxBytes}){
 const size=lstatSync(filename).size;if(size<36||size>maxBytes+20*1024*1024)throw failure(503,'BACKUP_INTEGRITY_FAILED','The encrypted backup has an invalid size.');const fd=openSync(filename,'r');let header,tag;try{header=Buffer.alloc(20);tag=Buffer.alloc(16);const {readSync}=await import('node:fs');if(readSync(fd,header,0,20,0)!==20||readSync(fd,tag,0,16,size-16)!==16||!header.subarray(0,8).equals(magic))throw new Error();}catch{throw failure(503,'BACKUP_INTEGRITY_FAILED','The encrypted backup header is invalid.');}finally{closeSync(fd);}
 const decipher=createDecipheriv('aes-256-gcm',Buffer.from(key),header.subarray(8));decipher.setAAD(aad);decipher.setAuthTag(tag);const compressed=createReadStream(filename,{start:20,end:size-17}).pipe(decipher).pipe(createGunzip());
 let buffer=Buffer.alloc(0),manifestLength=null,manifest=null,index=0,out,remaining=0,hash,total=0;
 try{for await(const chunk of compressed){total+=chunk.length;if(total>maxBytes+16*1024*1024+4)throw new Error();buffer=Buffer.concat([buffer,chunk]);if(manifestLength===null&&buffer.length>=4){manifestLength=buffer.readUInt32BE(0);buffer=buffer.subarray(4);if(manifestLength>16*1024*1024||manifestLength<10)throw new Error();}if(!manifest&&manifestLength!==null&&buffer.length>=manifestLength){manifest=JSON.parse(buffer.subarray(0,manifestLength).toString('utf8'));buffer=buffer.subarray(manifestLength);if(manifest.version!==1||!Array.isArray(manifest.files)||manifest.files.length<1||manifest.files.length>3||!manifest.files.some(x=>x.name==='academy.sqlite'))throw new Error();const names=new Set();let expected=0;for(const file of manifest.files){if(!fileNames.has(file.name)||names.has(file.name)||!Number.isSafeInteger(file.size)||file.size<0||!/^[a-f0-9]{64}$/.test(file.sha256))throw new Error();names.add(file.name);expected+=file.size;}if(expected>maxBytes)throw new Error();}
  while(manifest&&index<manifest.files.length){const file=manifest.files[index];if(out===undefined){out=openSync(path.join(directory,file.name),constants.O_CREAT|constants.O_EXCL|constants.O_WRONLY,0o600);remaining=file.size;hash=createHash('sha256');}if(!buffer.length&&remaining)break;const count=Math.min(remaining,buffer.length);if(count){const part=buffer.subarray(0,count);writeFileSync(out,part);hash.update(part);buffer=buffer.subarray(count);remaining-=count;}if(remaining===0){fsyncSync(out);closeSync(out);out=undefined;if(hash.digest('hex')!==file.sha256)throw new Error();index++;}else break;}
 }if(!manifest||index!==manifest.files.length||buffer.length||out!==undefined)throw new Error();return manifest;
 }catch(error){compressed.destroy();decipher.destroy();if(out!==undefined)closeSync(out);throw failure(503,'BACKUP_INTEGRITY_FAILED','The encrypted backup could not be authenticated and verified.');}
}
async function inspectRecovery({directory,manifest,ledger}){
 const restored=new DatabaseSync(path.join(directory,'academy.sqlite'));try{restored.exec('PRAGMA foreign_keys=ON; PRAGMA secure_delete=ON;');const integrity=()=>{if(restored.prepare('PRAGMA integrity_check').all().some(row=>row.integrity_check!=='ok')||restored.prepare('PRAGMA foreign_key_check').all().length)throw failure(503,'RECOVERY_DATABASE_FAILED','The restored database failed its integrity or relationship checks.');};integrity();if(schemaHash(restored)!==manifest.schemaHash)throw failure(503,'RECOVERY_SCHEMA_FAILED','The restored database schema does not match its manifest.');for(const table of ['users','accounts','sessions','two_factor'])if(!has(restored,table))throw failure(503,'RECOVERY_SCHEMA_FAILED','The backup is missing an application security table.');const selected=mergeLedgers(manifest.deletionLedger,ledger);if(!selected||!Array.isArray(selected.entries))throw failure(503,'RECOVERY_LEDGER_REQUIRED','A current account-deletion ledger is required for recovery.');let replayed=0;if(selected.installationId){const {applyAccountDeletionLedger}=await import('./account-controls.mjs');const result=applyAccountDeletionLedger(restored,selected);replayed=result?.replayed??selected.entries.length;}else if(selected.entries.length)throw failure(503,'RECOVERY_LEDGER_REQUIRED','The account-deletion ledger cannot be verified.');const keys=checkAuthenticationKeys(restored,directory);restored.exec('BEGIN IMMEDIATE');let resetCount;try{resetCount=clearRestoredAuthentication(restored);restored.exec('COMMIT');}catch(error){restored.exec('ROLLBACK');throw error;}integrity();restored.exec('PRAGMA wal_checkpoint(TRUNCATE);');return{integrity:'ok',foreignKeys:'ok',schema:'verified',deletionsReapplied:replayed,passwordResetsRequired:resetCount,oldSessionsRevoked:true,recoveryCodesRevoked:true,...keys,records:{users:rowCount(restored,'users'),certificates:rowCount(restored,'certificates'),sponsoredAccounts:rowCount(restored,'sponsored_accounts')}};}finally{restored.close();}
}
async function workerTask(input){if(input.task==='pack')return packBackup(input);if(input.task==='recover'){const manifest=await unpackBackup(input);const result=await inspectRecovery({directory:input.directory,manifest,ledger:input.ledger});return{...result,createdAt:manifest.createdAt};}throw failSafe();}
function inWorker(input){return new Promise((resolve,reject)=>{const worker=new Worker(new URL(import.meta.url),{workerData:{academyOperations:true,...input}});let complete=false;worker.once('message',result=>{complete=true;if(result.ok)resolve(result.value);else reject(failure(503,result.code||'OPERATIONS_FAILED',result.message||'The operational check failed.'));});worker.once('error',()=>reject(failSafe()));worker.once('exit',code=>{if(!complete||code!==0)reject(failSafe());});});}

export function createOperations(db,databasePath,{now=Date.now,backupDirectory=process.env.BACKUP_DIRECTORY||path.join(path.dirname(databasePath),'backups'),backupIntervalMs=Number(process.env.BACKUP_INTERVAL_HOURS||24)*3600000,backupRetention=process.env.BACKUP_RETENTION_COUNT||7,encryptionKey=process.env.BACKUP_ENCRYPTION_KEY,twoFactorEncryptionKey=process.env.TWO_FACTOR_ENCRYPTION_KEY,deletionLedger:getDeletionLedger,autoStart=false,initialDelayMs=30000,maxBackupBytes=128*1024*1024}={}){
 const source=noSymlink(databasePath),directory=privateDirectory(backupDirectory);if(!existsSync(source)||!lstatSync(source).isFile())throw failure(503,'BACKUP_SOURCE_MISSING','Start the academy database before configuring operations.');if(process.platform!=='win32')chmodSync(source,0o600);
 claimBackupDirectory(directory,source);
 const interval=integer(backupIntervalMs,86400000,60000,30*86400000,'backup interval'),retention=integer(backupRetention,7,1,90,'backup retention count'),delay=integer(initialDelayMs,30000,10,86400000,'initial backup delay'),sizeLimit=integer(maxBackupBytes,128*1024*1024,1024,1024*1024*1024,'backup size limit');
 const keyState=loadBackupKey(path.join(path.dirname(source),'backup-key.json'),encryptionKey,directory);const key=keyState.key;
 db.exec(`CREATE TABLE IF NOT EXISTS operations_errors(id TEXT PRIMARY KEY,category TEXT NOT NULL,code TEXT NOT NULL,route TEXT NOT NULL,method TEXT NOT NULL,description TEXT NOT NULL,count INTEGER NOT NULL,first_seen INTEGER NOT NULL,last_seen INTEGER NOT NULL,state TEXT NOT NULL DEFAULT 'open');CREATE INDEX IF NOT EXISTS operations_errors_seen ON operations_errors(last_seen DESC);CREATE TABLE IF NOT EXISTS operations_backups(id TEXT PRIMARY KEY,created_at INTEGER NOT NULL,bytes INTEGER NOT NULL,verified_at INTEGER,state TEXT NOT NULL);CREATE TABLE IF NOT EXISTS operations_runs(id TEXT PRIMARY KEY,kind TEXT NOT NULL,status TEXT NOT NULL,started_at INTEGER NOT NULL,completed_at INTEGER,result TEXT NOT NULL DEFAULT '{}',failure_code TEXT);CREATE TABLE IF NOT EXISTS operations_job_lease(singleton INTEGER PRIMARY KEY CHECK(singleton=1),owner TEXT NOT NULL,process_id INTEGER NOT NULL,run_id TEXT NOT NULL,expires_at INTEGER NOT NULL);CREATE TABLE IF NOT EXISTS operations_temporary_paths(path TEXT PRIMARY KEY,kind TEXT NOT NULL CHECK(kind IN ('snapshot','recovery','pending')),owner TEXT NOT NULL,process_id INTEGER NOT NULL);`);
 if(!db.prepare('PRAGMA table_info(users)').all().some(x=>x.name==='recovery_required'))db.exec('ALTER TABLE users ADD COLUMN recovery_required INTEGER NOT NULL DEFAULT 0');
 let timer=null,closed=false,active=null,currentLease=null;const previousLiveProcesses=new Set();
 const previousLease=db.prepare('SELECT * FROM operations_job_lease WHERE singleton=1').get();
 if(previousLease&&processAlive(previousLease.process_id))previousLiveProcesses.add(previousLease.process_id);
 if(previousLease&&!processAlive(previousLease.process_id)){db.prepare("UPDATE operations_runs SET status='failed',completed_at=?,failure_code='PROCESS_RESTARTED' WHERE id=? AND status='running'").run(now(),previousLease.run_id);db.prepare('DELETE FROM operations_job_lease WHERE owner=?').run(previousLease.owner);}
 function cleanupOrphans(){
  const lease=db.prepare('SELECT owner,process_id FROM operations_job_lease WHERE singleton=1').get();
  if(lease&&lease.owner!==currentLease&&processAlive(lease.process_id))return;
  const registered=db.prepare('SELECT path,kind,owner,process_id FROM operations_temporary_paths').all();
  const protectedPaths=new Set();let preserveUnknown=[...previousLiveProcesses].some(processAlive);
  for(const item of registered){
   if(item.owner===currentLease||processAlive(item.process_id)){protectedPaths.add(item.path);if(item.owner!==currentLease)preserveUnknown=true;continue;}
   const name=path.basename(item.path),valid=item.kind==='snapshot'?name.startsWith('.academy-snapshot-'):item.kind==='recovery'?name.startsWith('.academy-recovery-'):uuid.test(name.replace(/\.pending$/,''))&&name.endsWith('.pending');
   if(!valid)continue;
   let filename;try{filename=noSymlink(item.path);}catch{continue;}
   if(existsSync(filename)){const meta=lstatSync(filename);if(meta.isSymbolicLink()||item.kind==='pending'&&!meta.isFile()||item.kind!=='pending'&&!meta.isDirectory())continue;rmSync(filename,{recursive:item.kind!=='pending',force:true});}
   db.prepare('DELETE FROM operations_temporary_paths WHERE path=? AND owner=?').run(item.path,item.owner);
  }
  if(preserveUnknown)return;
  for(const name of readdirSync(directory)){
   const isDirectory=name.startsWith('.academy-snapshot-')||name.startsWith('.academy-recovery-');
   const isPending=name.endsWith('.pending')&&uuid.test(name.slice(0,-8));
   if(!isDirectory&&!isPending)continue;
   const filename=path.join(directory,name);if(protectedPaths.has(filename))continue;
   const meta=lstatSync(filename);if(meta.isSymbolicLink()||isDirectory&&!meta.isDirectory()||isPending&&!meta.isFile())continue;
   rmSync(filename,{recursive:isDirectory,force:true});
  }
 }
 function trackTemporary(filename,kind){assertLease();db.prepare('INSERT INTO operations_temporary_paths(path,kind,owner,process_id) VALUES (?,?,?,?)').run(filename,kind,currentLease,process.pid);}
 function forgetTemporary(filename){if(!existsSync(filename))db.prepare('DELETE FROM operations_temporary_paths WHERE path=? AND owner=?').run(filename,currentLease);}
 const ownsCleanupTransaction=!db.isTransaction;
 if(ownsCleanupTransaction)db.exec('BEGIN IMMEDIATE');
 try{cleanupOrphans();if(ownsCleanupTransaction)db.exec('COMMIT');}catch(error){if(ownsCleanupTransaction)db.exec('ROLLBACK');throw error;}
const latest=db.prepare("SELECT max(created_at) value FROM operations_backups WHERE state='verified'").get().value;let nextBackupAt=latest?Math.max(now()+1000,latest+interval):now()+delay;
 const ledger=()=>getDeletionLedger?getDeletionLedger():deletionLedger(db,now());
 function capture(error,{route='/internal',method='JOB',status=500}={}){try{if(!Number.isInteger(status)||status<500)return null;const normalized=String(route).split(/[?#]/,1)[0].slice(0,300).split('/').map(part=>/^\d+$/.test(part)||uuid.test(part)?':id':routeWords.has(part)?part:':value').join('/');const verb=['GET','POST','PUT','PATCH','DELETE','JOB','PROCESS'].includes(method)?method:'OTHER';const supplied=typeof error?.code==='string'?error.code:'';const code=/^(?:SQLITE_[A-Z_]{1,40}|E(?:CONNRESET|CONNREFUSED|TIMEDOUT|NOSPC|ACCES|PERM|IO)|BACKUP_[A-Z_]{1,40}|RECOVERY_[A-Z_]{1,40}|OPERATIONS_[A-Z_]{1,40})$/.test(supplied)?supplied:'INTERNAL_ERROR';const category=code.startsWith('SQLITE_')?'database':code.startsWith('BACKUP_')||code.startsWith('RECOVERY_')?'backup':'application';const description=category==='database'?'A database operation failed.':category==='backup'?'A backup or recovery operation failed.':'An application request failed.';const id=digest(`${category}:${code}:${normalized}:${verb}`);db.prepare("INSERT INTO operations_errors(id,category,code,route,method,description,count,first_seen,last_seen,state) VALUES(?,?,?,?,?,?,1,?,?,'open') ON CONFLICT(id) DO UPDATE SET count=min(count+1,9007199254740991),last_seen=excluded.last_seen,state='open'").run(id,category,code,normalized,verb,description,now(),now());db.prepare('DELETE FROM operations_errors WHERE last_seen<?').run(now()-30*86400000);db.prepare('DELETE FROM operations_errors WHERE id IN (SELECT id FROM operations_errors ORDER BY last_seen DESC LIMIT -1 OFFSET 500)').run();return{id,code};}catch{return null;}}
 function errors({limit=50,offset=0,state='open'}={}){limit=integer(limit,50,1,100,'error page size');offset=integer(offset,0,0,1000000,'error page offset');if(!['open','resolved','all'].includes(state))throw failure(400,'OPERATIONS_INVALID_INPUT','Choose a valid error state.');const where=state==='all'?'':' WHERE state=?',args=state==='all'?[]:[state];const total=db.prepare('SELECT count(*) total FROM operations_errors'+where).get(...args).total;const items=db.prepare('SELECT id,category,code,route,method,description,count,first_seen firstSeen,last_seen lastSeen,state FROM operations_errors'+where+' ORDER BY last_seen DESC,id LIMIT ? OFFSET ?').all(...args,limit,offset);return{items,total,limit,offset,nextOffset:offset+items.length<total?offset+items.length:null};}
 function resolveError(id){if(typeof id!=='string'||!/^[a-f0-9]{64}$/.test(id))throw failure(400,'OPERATIONS_INVALID_INPUT','Select a recorded operational error.');if(!db.prepare("UPDATE operations_errors SET state='resolved' WHERE id=?").run(id).changes)throw failure(404,'OPERATIONS_NOT_FOUND','The operational error was not found.');return{id,state:'resolved'};}
 function jobRunning(){const lease=db.prepare('SELECT process_id,expires_at FROM operations_job_lease WHERE singleton=1').get();return Boolean(active)||Boolean(lease&&lease.expires_at>now()&&processAlive(lease.process_id));}
 function status(){return{enabled:!closed,automaticBackups:Boolean(timer),encrypted:true,keySource:keyState.source,keyCopyRequired:keyState.source==='private_file',offsiteConfigured:false,persistentStorageRequired:true,storage:'Private local filesystem',backupIntervalHours:interval/3600000,retentionCount:retention,nextBackupAt:closed?null:nextBackupAt,running:jobRunning(),maxBackupBytes:sizeLimit,backupKeyNotice:'Keep a separate secure copy of the backup encryption key. It is deliberately excluded from backup artifacts.',recoveryNotice:'Recovery creates a new private directory, reapplies the current deletion ledger, and requires new password resets before sign-in. It never replaces a running database.',backups:db.prepare('SELECT id,created_at createdAt,bytes,verified_at verifiedAt,state FROM operations_backups ORDER BY created_at DESC,id LIMIT 100').all(),recentRuns:db.prepare('SELECT id,kind,status,started_at startedAt,completed_at completedAt,failure_code failureCode,result FROM operations_runs ORDER BY started_at DESC,id LIMIT 20').all().map(x=>({...x,result:JSON.parse(x.result)})),errors:{open:db.prepare("SELECT count(*) n FROM operations_errors WHERE state='open'").get().n}};}
 function artifact(id){if(typeof id!=='string'||!uuid.test(id))throw failure(400,'OPERATIONS_INVALID_INPUT','Select a valid backup.');if(!db.prepare('SELECT 1 FROM operations_backups WHERE id=?').get(id))throw failure(404,'BACKUP_NOT_FOUND','The selected backup was not found.');const file=path.join(directory,id+'.fabackup');if(!existsSync(file)||!lstatSync(file).isFile()||lstatSync(file).isSymbolicLink())throw failure(503,'BACKUP_INTEGRITY_FAILED','The backup artifact is unavailable or unsafe.');return file;}
 function assertLease(){
  if(!currentLease||!db.prepare('SELECT 1 FROM operations_job_lease WHERE singleton=1 AND owner=?').get(currentLease))throw failure(409,'OPERATIONS_LEASE_LOST','Another operational worker replaced this job. Retry after the active job completes.');
 }
 function exclusive(kind,work){
  if(closed)return Promise.reject(failure(503,'OPERATIONS_STOPPED','The operational service is stopping.'));
  if(active)return Promise.reject(failure(409,'OPERATIONS_BUSY','A backup or recovery check is already running.'));
  const id=randomUUID(),owner=randomUUID(),startedAt=now();
  if(db.isTransaction)return Promise.reject(failure(409,'OPERATIONS_BUSY','Finish the active database transaction before starting an operational job.'));
  try{
    db.exec('BEGIN IMMEDIATE');
    const previous=db.prepare('SELECT * FROM operations_job_lease WHERE singleton=1').get();
    if(previous&&processAlive(previous.process_id)&&previous.expires_at>now())throw failure(409,'OPERATIONS_BUSY','A backup or recovery check is already running.');
    if(previous&&processAlive(previous.process_id))previousLiveProcesses.add(previous.process_id);
    if(previous)db.prepare("UPDATE operations_runs SET status='failed',completed_at=?,failure_code='PROCESS_RESTARTED' WHERE id=? AND status='running'").run(now(),previous.run_id);
    db.prepare("UPDATE operations_runs SET status='failed',completed_at=?,failure_code='PROCESS_RESTARTED' WHERE status='running'").run(now());
    db.prepare('INSERT INTO operations_job_lease(singleton,owner,process_id,run_id,expires_at) VALUES(1,?,?,?,?) ON CONFLICT(singleton) DO UPDATE SET owner=excluded.owner,process_id=excluded.process_id,run_id=excluded.run_id,expires_at=excluded.expires_at').run(owner,process.pid,id,now()+600000);
    db.prepare("INSERT INTO operations_runs(id,kind,status,started_at) VALUES(?,?,'running',?)").run(id,kind,startedAt);
    currentLease=owner;cleanupOrphans();
    db.exec('COMMIT');
  }catch(error){currentLease=null;if(db.isTransaction)db.exec('ROLLBACK');return Promise.reject(error);}
  currentLease=owner;
  const heartbeat=setInterval(()=>{try{db.prepare('UPDATE operations_job_lease SET expires_at=? WHERE singleton=1 AND owner=?').run(now()+600000,owner);}catch{}},30000);heartbeat.unref();
  const task=Promise.resolve().then(()=>{assertLease();return work();}).then(result=>{
    assertLease();db.prepare("UPDATE operations_runs SET status='completed',completed_at=?,result=? WHERE id=?").run(now(),JSON.stringify(result),id);return{...result,operationId:id};
  }).catch(error=>{
    const safeCode=/^(?:BACKUP|RECOVERY|OPERATIONS|DELETION_LEDGER)_[A-Z_]{1,60}$/.test(error?.code||'')?error.code:'OPERATIONS_FAILED';
    db.prepare("UPDATE operations_runs SET status='failed',completed_at=?,failure_code=? WHERE id=?").run(now(),safeCode,id);
    capture({code:safeCode},{route:'/operations/'+kind,method:'JOB',status:500});if(error?.status&&error?.code)throw error;throw failSafe();
  }).finally(()=>{clearInterval(heartbeat);db.prepare('DELETE FROM operations_job_lease WHERE singleton=1 AND owner=?').run(owner);currentLease=null;active=null;});
  active=task;return task;
 }
 async function recoveryWork(id,{targetDirectory}={}){
  const file=artifact(id);
  const parent=targetDirectory?noSymlink(path.dirname(path.resolve(targetDirectory))):directory;
  if(!existsSync(parent)||!lstatSync(parent).isDirectory())throw failure(400,'BACKUP_PATH_UNSAFE','The recovery parent directory must already exist.');
  if(targetDirectory&&existsSync(noSymlink(targetDirectory)))throw failure(409,'RECOVERY_TARGET_EXISTS','Recovery only writes to a new directory; the destination already exists.');
  const temporary=mkdtempSync(path.join(parent,'.academy-recovery-'));
  if(process.platform!=='win32')chmodSync(temporary,0o700);
  try{
    trackTemporary(temporary,'recovery');
    const currentLedger=ledger();
    const result=await inWorker({task:'recover',filename:file,directory:temporary,key,maxBytes:sizeLimit,ledger:currentLedger});
    assertLease();
    if(ledgerFingerprint(currentLedger)!==ledgerFingerprint(ledger()))throw failure(409,'RECOVERY_LEDGER_CHANGED','Account deletion records changed during recovery. Run the check again with the current deletion ledger.');
    if(targetDirectory){
      if(existsSync(noSymlink(targetDirectory)))throw failure(409,'RECOVERY_TARGET_EXISTS','Recovery only writes to a new directory; the destination already exists.');
      renameSync(temporary,noSymlink(targetDirectory));
      return{backupId:id,...result,restoredToNewDirectory:true,requiresPasswordResets:true};
    }
    db.prepare("UPDATE operations_backups SET verified_at=?,state='verified' WHERE id=?").run(now(),id);
    return{backupId:id,...result,checkedAt:now(),productionModified:false};
  }catch(error){
    if(!targetDirectory&&error.code!=='RECOVERY_LEDGER_CHANGED')db.prepare("UPDATE operations_backups SET state='verification_failed' WHERE id=?").run(id);
    throw error;
  }finally{if(existsSync(temporary))rmSync(temporary,{recursive:true,force:true});forgetTemporary(temporary);}
 }
 function rotate(){cleanupOrphans();const rows=db.prepare("SELECT id FROM operations_backups ORDER BY created_at DESC,id DESC").all();for(const row of rows.slice(retention)){const filename=path.join(directory,row.id+'.fabackup');if(existsSync(filename))unlinkSync(filename);db.prepare('DELETE FROM operations_backups WHERE id=?').run(row.id);}db.prepare("DELETE FROM operations_runs WHERE completed_at<? AND status<>'running'").run(now()-30*86400000);}
 function backup(){return exclusive('backup',async()=>{const id=randomUUID(),createdAt=now(),temporary=mkdtempSync(path.join(directory,'.academy-snapshot-')),pending=path.join(directory,id+'.pending');if(process.platform!=='win32')chmodSync(temporary,0o700);try{trackTemporary(temporary,'snapshot');trackTemporary(pending,'pending');await sqliteBackup(db,path.join(temporary,'academy.sqlite'),{rate:100});assertLease();const keys=[];for(const name of ['two-factor-key.json','vapid.json']){let content;if(name==='two-factor-key.json'&&twoFactorEncryptionKey){content=Buffer.from(JSON.stringify({version:1,key:parseKey(twoFactorEncryptionKey,'TWO_FACTOR_ENCRYPTION_KEY').toString('base64')}));}else content=privateRead(path.join(path.dirname(source),name),{required:false});if(content){writeFileSync(path.join(temporary,name),content,{mode:0o600,flag:'wx'});keys.push(name);}}const packed=await inWorker({task:'pack',directory:temporary,destination:pending,key,createdAt,ledger:ledger(),maxBytes:sizeLimit});assertLease();const filename=path.join(directory,id+'.fabackup');renameSync(pending,filename);db.prepare("INSERT INTO operations_backups(id,created_at,bytes,state) VALUES(?,?,?,'unchecked')").run(id,createdAt,packed.bytes);const checked=await recoveryWork(id);rotate();nextBackupAt=now()+interval;return{backupId:id,createdAt,bytes:packed.bytes,encrypted:true,authenticationKeysIncluded:keys,verified:true,recovery:checked};}catch(error){const failedArtifact=path.join(directory,id+'.fabackup');if(existsSync(failedArtifact))unlinkSync(failedArtifact);db.prepare('DELETE FROM operations_backups WHERE id=?').run(id);throw error;}finally{if(existsSync(pending))unlinkSync(pending);rmSync(temporary,{recursive:true,force:true});forgetTemporary(pending);forgetTemporary(temporary);}});}
 function checkRecovery(id){const selected=id||db.prepare("SELECT id FROM operations_backups ORDER BY created_at DESC,id DESC LIMIT 1").get()?.id;if(!selected)return Promise.reject(failure(404,'BACKUP_NOT_FOUND','Create a backup before running a recovery check.'));return exclusive('verify',()=>recoveryWork(selected));}
 function restoreToDirectory(id,{targetDirectory,confirmation}={}){if(typeof targetDirectory!=='string'||!targetDirectory||confirmation!=='RESTORE TO NEW DIRECTORY')return Promise.reject(failure(400,'RECOVERY_CONFIRMATION_REQUIRED','Confirm recovery to a new private directory.'));return exclusive('restore',()=>recoveryWork(id,{targetDirectory}));}
 async function runScheduled(){if(closed||active||now()<nextBackupAt)return null;try{return await backup();}catch(error){nextBackupAt=now()+Math.min(interval,3600000);throw error;}}
 function start(){if(closed)throw failure(503,'OPERATIONS_STOPPED','The operational service is stopping.');if(timer)return;timer=setInterval(()=>{void runScheduled().catch(()=>{});},Math.min(30000,delay));timer.unref();process.on('uncaughtExceptionMonitor',onFatal);}
 function onFatal(error){capture(error,{route:'/process/uncaught',method:'PROCESS',status:500});}
 async function close(){closed=true;if(timer){clearInterval(timer);timer=null;}process.removeListener('uncaughtExceptionMonitor',onFatal);if(active)await active.catch(()=>{});}
 if(autoStart)start();return{capture,errors,resolveError,status,backup,checkRecovery,restoreToDirectory,runScheduled,start,close};
}

if(!isMainThread&&workerData?.academyOperations){workerTask(workerData).then(value=>parentPort.postMessage({ok:true,value}),error=>parentPort.postMessage({ok:false,code:/^[A-Z_]{3,80}$/.test(error?.code||'')?error.code:'OPERATIONS_FAILED',message:error?.status?error.message:'The operational check could not complete.'}));}
